
public class interval {
	public int start;
	public int end;
	

	public interval(int givens, int givene)
	{
		
		this.start = givens;
		this.end = givene;
	}
}
