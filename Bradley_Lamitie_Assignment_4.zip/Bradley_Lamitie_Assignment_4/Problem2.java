
public class Problem2 {

	public static double findmaxdiff(double[] A){
		// Complete the method to find the maximum difference of a given array A
		  double max = A[1] - A[0];
		  double min = A[0];
		  int i;
		  for(i = 1; i < A.length; i++)
		  {       
		    if (A[i] - min > max)                               
		      max = A[i] - min;
		    if (A[i] < min)
		         min = A[i];                     
		  }
		  return max;
		
	}
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// Test your findmaxdiff() method here
		
		double[] testarray1 = {2, 3, 10, 6, 4, 8, 1};
		// maxdiff: 8
		     
		double[] testarray2 = {7, 9, 5, 6, 3, 2};
		// maxdiff: 2
		
		System.out.println("The maxdiff is " + findmaxdiff(testarray1));
		
		System.out.println("The maxdiff of testarray2 is " + findmaxdiff(testarray2));
		
		
		
		
		
		
	}

}
