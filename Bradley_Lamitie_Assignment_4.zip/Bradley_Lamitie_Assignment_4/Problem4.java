
public class Problem4 {

	
	public static int count(double[] A, double x)
	{
		// complete the method count() here
		int i; // index of first occurrence of x in arr[0..n-1]
		  int j; // index of last occurrence of x in arr[0..n-1]
		     int n = A.length;
		  /* get the index of first occurrence of x */
		  i = first(A, 0, n-1, x, n);
		 
		  /* If x doesn't exist in arr[] then return -1 */
		  if(i == -1)
		    return i;
		    
		  /* Else get the index of last occurrence of x. Note that we 
		      are only looking in the subarray after first occurrence */  
		  j = last(A, i, n-1, x, n);     
		    
		  /* return count */
		  return j-i+1;
		
	}
	
	static int first(double A[], int low, int high, double x, int n)
	{
	  if(high >= low)
	  {
	    int mid = (low + high)/2;  /*low + (high - low)/2;*/
	    if( ( mid == 0 || x > A[mid-1]) && A[mid] == x)
	      return mid;
	    else if(x > A[mid])
	      return first(A, (mid + 1), high, x, n);
	    else
	      return first(A, low, (mid -1), x, n);
	  }
	  return -1;
	}
	 
	 
	/* if x is present in arr[] then returns the index of LAST occurrence 
	   of x in arr[0..n-1], otherwise returns -1 */
	static int last(double A[], int low, int high, double x, int n)
	{
	  if(high >= low)
	  {
	    int mid = (low + high)/2;  /*low + (high - low)/2;*/
	    if( ( mid == n-1 || x < A[mid+1]) && A[mid] == x )
	      return mid;
	    else if(x < A[mid])
	      return last(A, low, (mid -1), x, n);
	    else
	      return last(A, (mid + 1), high, x, n);      
	  }
	  return -1;
	}
	 
	
	
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// test your count() method here
		
		double[] testarray = {1.3, 2.1, 2.1, 2.1, 2.1, 6.7, 7.5, 7.5, 8.6, 9.0};
		double t1 = 2.1;
		double t2 = 7.5;
		double t3 = 1.3;
		System.out.println(t1+" appears "+ count(testarray, t1) + " times");
		System.out.println(t2+" appears "+ count(testarray, t2) + " times");
		System.out.println(t3+" appears "+ count(testarray, t3) + " times");
		
		
		
	}

}
